/*****************************************
* This is a library for the ADS1015 A/D Converter based on ADS1115 A/D library writed by Wolfang Ewald
*
* You'll find an example which should enable you to use the library. 
*
* You are free to use it, change it or build on it. In case you like 
* it, it would be cool if you give it a star.
* 
* If you find bugs, please inform me!
* 
* Written by Wolfgang (Wolle) Ewald
* https://wolles-elektronikkiste.de/en/ads1115-a-d-converter-with-amplifier (English)
* https://wolles-elektronikkiste.de/ads1115 (German)
*
*******************************************/

#include "ADS1015_WE.h"

void ADS1015_WE::reset(){
#ifndef USE_TINY_WIRE_M_  
    _wire->beginTransmission(0);
    _wire->write(0x06);
    _wire->endTransmission();
#else
    TinyWireM.beginTransmission(0);
    TinyWireM.send(0x06);
    TinyWireM.endTransmission();
#endif
}

bool ADS1015_WE::init(){    
#ifndef USE_TINY_WIRE_M_
    _wire->beginTransmission(i2cAddress);
    uint8_t success = _wire->endTransmission();
#else
    TinyWireM.beginTransmission(i2cAddress);
    uint8_t success = TinyWireM.endTransmission();
#endif
    if(success){
        return 0;
    }
    writeRegister(ADS1015_CONFIG_REG, ADS1015_REG_RESET_VAL);
    setVoltageRange_mV(ADS1015_RANGE_2048);
    writeRegister(ADS1015_LO_THRESH_REG, 0x800);
    writeRegister(ADS1015_HI_THRESH_REG, 0x7FF);
    deviceMeasureMode = ADS1015_SINGLE;
    return 1;
}

void ADS1015_WE::setAlertPinMode(ADS1015_COMP_QUE mode){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg &= ~(0x8003);    
    currentConfReg |= mode;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
}

void ADS1015_WE::setAlertLatch(ADS1015_LATCH latch){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg &= ~(0x8004);    
    currentConfReg |= latch;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
}

void ADS1015_WE::setAlertPol(ADS1015_ALERT_POL polarity){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg &= ~(0x8008);    
    currentConfReg |= polarity;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
}

void ADS1015_WE::setAlertModeAndLimit_V(ADS1015_COMP_MODE mode, float hiThres, float loThres){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg &= ~(0x8010);    
    currentConfReg |= mode;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
    int16_t alertLimit = calcLimit(hiThres);
    writeRegister(ADS1015_HI_THRESH_REG, alertLimit);
    alertLimit = calcLimit(loThres);
    writeRegister(ADS1015_LO_THRESH_REG, alertLimit);
    
}

void ADS1015_WE::setConvRate(ADS1015_CONV_RATE rate){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg &= ~(0x80E0);    
    currentConfReg |= rate;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
}

convRate ADS1015_WE::getConvRate(){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    return (convRate)(currentConfReg & 0xE0);
}
    
void ADS1015_WE::setMeasureMode(ADS1015_MEASURE_MODE mode){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    deviceMeasureMode = mode;
    currentConfReg &= ~(0x8100);    
    currentConfReg |= mode;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
}

void ADS1015_WE::setVoltageRange_mV(ADS1015_RANGE range){
    //uint16_t currentVoltageRange = voltageRange;
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    //uint16_t currentRange = (currentConfReg >> 9) & 7;
    //uint16_t currentAlertPinMode = currentConfReg & 3;
    
    setMeasureMode(ADS1015_SINGLE);
    
    switch(range){
        case ADS1015_RANGE_6144:
            voltageRange = 6144;
            break;
        case ADS1015_RANGE_4096:
            voltageRange = 4096;
            break;
        case ADS1015_RANGE_2048:
            voltageRange = 2048;
            break;
        case ADS1015_RANGE_1024:
            voltageRange = 1024;
            break;
        case ADS1015_RANGE_0512:
            voltageRange = 512;
            break;
        case ADS1015_RANGE_0256:
            voltageRange = 256;
            break;
    }    
        
    currentConfReg &= ~(0x8E00);    
    currentConfReg |= range;
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
    convRate rate = getConvRate();
    delayAccToRate(rate);
}
       
void ADS1015_WE::delayAccToRate(convRate cr){
    switch(cr){
        case ADS1015_128_SPS:
            delay(8);
            break;
        case ADS1015_250_SPS:
            delay(4);
            break;
        case ADS1015_490_SPS:
            delay(2);
            break;
        case ADS1015_920_SPS:
            delay(1);
            break;
        case ADS1015_1600_SPS:
            delayMicroseconds(700);
            break;
        case ADS1015_2400_SPS:
            delayMicroseconds(400);
            break;
        case ADS1015_3300_SPS:
            delayMicroseconds(300);
            break;

    }
}
    

void ADS1015_WE::setCompareChannels(ADS1015_MUX mux){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg &= ~(0xF000);    
    currentConfReg |= (mux);
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
    
    if(!(currentConfReg & 0x0100)){  // => if not single shot mode
        convRate rate = getConvRate();      
        delayAccToRate(rate);
        delayAccToRate(rate);               
    }       
}

void ADS1015_WE::setSingleChannel(size_t channel) {
    if (channel >=  4)
        return;
    setCompareChannels((ADS1015_MUX)(ADS1015_COMP_0_GND + ADS1015_COMP_INC*channel));
}
   
void ADS1015_WE::startSingleMeasurement(){
    uint16_t currentConfReg = readRegister(ADS1015_CONFIG_REG);
    currentConfReg |= (1 << 15);
    writeRegister(ADS1015_CONFIG_REG, currentConfReg);
}
  

float ADS1015_WE::getResult_mV(){
	int16_t rawResult = getRawResult();
    float result = (rawResult * 1.0 / ADS1015_REG_FACTOR) * voltageRange;    
    return result;	
}

int16_t ADS1015_WE::getRawResult(){
    uint16_t rawResult = readRegister(ADS1015_CONV_REG)>>4;   
	if (rawResult > 0x07FF) {
      // negative number - extend the sign to 16th bit
      rawResult |= 0xF000;
    } 
    return (int16_t)rawResult;
}

void ADS1015_WE::setAlertPinToConversionReady(){
    writeRegister(ADS1015_LO_THRESH_REG, (0<<15));
    writeRegister(ADS1015_HI_THRESH_REG, (1<<15));
}

/************************************************ 
    private functions
*************************************************/

uint8_t ADS1015_WE::writeRegister(uint8_t reg, uint16_t val){
    uint8_t lVal = val & 255;
    uint8_t hVal = val >> 8;
#ifndef USE_TINY_WIRE_M_  
    _wire->beginTransmission(i2cAddress);
    _wire->write(reg);
    _wire->write(hVal);
    _wire->write(lVal);
    return _wire->endTransmission();
#else
    TinyWireM.beginTransmission(i2cAddress);
    TinyWireM.send(reg);
    TinyWireM.send(hVal);
    TinyWireM.send(lVal);
    return TinyWireM.endTransmission();
#endif
  
}
  
uint16_t ADS1015_WE::readRegister(uint8_t reg){
    uint8_t MSByte = 0, LSByte = 0;
    uint16_t regValue = 0;
#ifndef USE_TINY_WIRE_M_    
    _wire->beginTransmission(i2cAddress);
    _wire->write(reg);
    _wire->endTransmission(false);
    _wire->requestFrom(i2cAddress,static_cast<uint8_t>(2));
    if(_wire->available()){
        MSByte = _wire->read();
        LSByte = _wire->read();
    }
#else
    TinyWireM.beginTransmission(i2cAddress);
    TinyWireM.send(reg);
    TinyWireM.endTransmission();
    TinyWireM.requestFrom(i2cAddress,static_cast<uint8_t>(2));
    MSByte = TinyWireM.receive();
    LSByte = TinyWireM.receive();
#endif
    regValue = (MSByte<<8) + LSByte;
    return regValue;
}
